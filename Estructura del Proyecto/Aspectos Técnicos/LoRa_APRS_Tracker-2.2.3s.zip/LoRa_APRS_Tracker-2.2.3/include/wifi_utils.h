#ifndef WIFI_UTILS_H_
#define WIFI_UTILS_H_

#include <Arduino.h>


namespace WIFI_Utils {

    void startAutoAP();
    void checkIfWiFiAP();

}

#endif