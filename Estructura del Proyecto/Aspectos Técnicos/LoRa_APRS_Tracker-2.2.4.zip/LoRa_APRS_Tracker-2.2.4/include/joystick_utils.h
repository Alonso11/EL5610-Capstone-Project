#ifndef JOYSTICK_UTILS_H_
#define JOYSTICK_UTILS_H_

#include <Arduino.h>

namespace JOYSTICK_Utils {

    void loop();
    void setup();

}

#endif