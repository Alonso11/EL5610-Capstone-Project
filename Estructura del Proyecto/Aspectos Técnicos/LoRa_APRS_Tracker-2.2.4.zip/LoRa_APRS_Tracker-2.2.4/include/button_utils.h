#ifndef BUTTON_UTILS_H_
#define BUTTON_UTILS_H_

#include <Arduino.h>

namespace BUTTON_Utils {

    void longPress();
    void doublePress();

    void loop();
    void setup();

}

#endif